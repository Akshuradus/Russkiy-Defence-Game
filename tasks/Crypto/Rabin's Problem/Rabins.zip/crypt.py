OP=open('cipher.txt', 'r')
Cip=open('cipher.enc', 'w')
crypt=""
a=10000000000
for char in OP.read():
    crypt+= str((((ord(char)+a)**2)%1539508836011))+' '
    print(crypt)
Cip.write(crypt)
Cip.close()
